DROP TABLE opp_trace_settings
/

DROP TABLE opp_trace
/

DROP SEQUENCE opp_trace_seq
/

DROP PACKAGE opp_trace_pkg
/