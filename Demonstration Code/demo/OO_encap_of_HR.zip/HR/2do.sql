@alter_HR_tables.sql
@TYPE_OBJECT.sql
@ROW_COUNTRY.sql
@ROW_DEPARTMENT.sql
@ROW_EMPLOYEE.sql
@ROW_JOB.sql
@ROW_JOB_HISTORY.sql
@ROW_LOCATION.sql
@ROW_REGION.sql

@TYPE_REGION.sql
@TYPE_COUNTRY.sql
@TYPE_EMPLOYEE.sql





