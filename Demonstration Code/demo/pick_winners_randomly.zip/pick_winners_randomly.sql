BEGIN
   pick_winners_randomly (50, 10, '4,22,27,33,47');
END;
/