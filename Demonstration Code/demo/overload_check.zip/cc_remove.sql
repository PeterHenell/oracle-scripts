@@cc_testcase.rem

@@cc_remove_packages

