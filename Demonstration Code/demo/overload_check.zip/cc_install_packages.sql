prompt 
prompt Installing Codecheck Packages
prompt 
prompt First the package specifications...
prompt
prompt cc_util.pks
@@cc_util.pks
sho err
prompt cc_error.pks
@@cc_error.pks
sho err
prompt cc_names.pks
@@cc_names.pks
sho err
prompt cc_arguments.pks
@@cc_arguments.pks
sho err
prompt cc_types.pks
@@cc_types.pks
sho err
prompt cc_smartargs.pks
@@cc_smartargs.pks
sho err
prompt cc_report.pks
@@cc_report.pks
sho err
prompt codecheck.pks
@@codecheck.pks
sho err
prompt ut_codecheck.pks
@@ut_codecheck.pks
sho err

prompt 
prompt And now the package bodies...
prompt
prompt cc_util.pkb
@@cc_util.pkb
sho err
prompt cc_error.pkb
@@cc_error.pkb
sho err
prompt cc_names.pkb
@@cc_names.pkb
sho err
prompt cc_arguments.pkb
@@cc_arguments.pkb
sho err
prompt cc_types.pkb
@@cc_types.pkb
sho err
prompt cc_report.pkb
@@cc_report.pkb
sho err
prompt cc_smartargs.pkb
@@cc_smartargs.pkb
sho err
prompt codecheck.pkb
@@codecheck.pkb
sho err
prompt ut_codecheck.pkb
@@ut_codecheck.pkb
sho err

prompt ccovlds.pro
@@ccovlds.pro
sho err