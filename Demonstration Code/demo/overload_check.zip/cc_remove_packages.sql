drop package ut_codecheck;
drop package codecheck;
drop package cc_smartargs;
drop package cc_report;
drop package cc_arguments;
drop package cc_names;
drop package cc_types;
