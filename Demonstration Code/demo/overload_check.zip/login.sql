set serveroutput on format wrapped size 1000000
exec utconfig.setdir ('d:\openoracle\Codecheck')