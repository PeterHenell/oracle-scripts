BEGIN
   in_clause.gen_static_in_query ('IN_CLAUSE_TAB', 'list_in');
END;
