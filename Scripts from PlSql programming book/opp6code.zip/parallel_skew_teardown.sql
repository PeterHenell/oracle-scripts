
DROP TABLE parallel_skew_test;
DROP PACKAGE stocks_skew_pkg;

