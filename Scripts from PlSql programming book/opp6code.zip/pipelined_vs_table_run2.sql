
spool pipelined_vs_table_test2.txt
@pipelined_vs_table_test2.sql
spool off

