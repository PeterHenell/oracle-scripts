REM Remove any lines you don't need or don't apply to your situtation.

CREATE SEQUENCE department_seq;

@@DEPARTMENT_TP.pks
SHOW ERRORS
@@DEPARTMENT_QP.pks
SHOW ERRORS
@@DEPARTMENT_CP.pks
SHOW ERRORS

@@DEPARTMENT_QP.pkb
SHOW ERRORS
@@DEPARTMENT_CP.pkb
SHOW ERRORS

@@DEPARTMENT.trg
