
DROP TABLE customer_staging;
DROP PACKAGE customer_pkg;
DROP TABLE addresses;
DROP TABLE customers;
DROP TYPE address_detail_ot;
DROP TYPE customer_detail_ot;
DROP TYPE customer_ntt;
DROP TYPE customer_ot;
DROP TYPE customer_address_ntt;
DROP TYPE customer_address_ot;

