SELECT name
  FROM user_plsql_object_settings
 WHERE plsql_optimize_level IN (1,0);

